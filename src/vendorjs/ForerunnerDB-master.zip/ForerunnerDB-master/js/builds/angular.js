var Angular = require('../lib/Angular');

module.exports = Angular;
