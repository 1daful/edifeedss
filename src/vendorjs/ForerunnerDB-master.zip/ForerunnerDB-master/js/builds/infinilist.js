var Infinilist = require('../lib/Infinilist');

module.exports = Infinilist;
