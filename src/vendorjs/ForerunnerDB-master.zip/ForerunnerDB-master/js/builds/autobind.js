var AutoBind = require('../lib/AutoBind');

module.exports = AutoBind;
